import React from "react"
import "./../util/formContent.css"

class RegistrationSuccess extends React.Component {
    render() { 
        return <section>

        <h3>Registration Sucessfull</h3>
        <p>Thank you for your registration</p>
        <a >click to retrun to home page</a>
        
        </section>;
    }
}
 
export default RegistrationSuccess;