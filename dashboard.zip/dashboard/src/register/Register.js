import React from "react"
import "./../util/formContent.css"

class Register extends React.Component {
    render() { 
        return ( <section className="form">
        <h3>Register</h3>
        <p>
        <label htmlFor="fullName">Full Name</label>
        <input type="text" ></input>
        </p>
        <p>
        <label htmlFor="email">Email</label>
        <input type="email" ></input>
        </p>
        <p>
        <label htmlFor="Password">Password</label>
        <input type="password" ></input>
        </p>
        <p> 
        <label htmlFor="ConfirmPassword">Confirm Password</label>
        <input type="password" ></input>
        </p>
        <button>Register</button>
        </section> );
        
    }
}
 
export default Register;