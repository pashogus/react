import Nav from '../Nav'

function LoginSuccess() {
    const email = localStorage.getItem("email");

    return ( 
       <div>
        <Nav/>   
        <h2>Login Succesfull </h2>
        <p>Welcome {email}!</p>
        </div>
       );
}

export default LoginSuccess;