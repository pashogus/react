import React from "react";
import "./../util/formContent.css";
import style from "./Welcome.module.css";
import { useNavigate } from "react-router-dom"; // import useNavigate hook

const Welcome = () => {
  const navigate = useNavigate(); // hook for navigation

  const navigateToLogin = () => {
    navigate("/login"); // navigate to login page
  };

  const navigateToRegister = () => {
    navigate("/register"); // navigate to register page
  };

  return (
    <section>
      <h2>Welcome to Users Module</h2>
      <p>Existing Users</p>
      <button
        type="button"
        className="btn btn-primary"
        onClick={navigateToLogin}
      >
        Login
      </button>
      <p>New Users</p>
      <button
        type="button"
        className="btn btn-primary"
        onClick={navigateToRegister}
      >
        Register
      </button>
    </section>
  );
};

export default Welcome;
