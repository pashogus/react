import React, { useState, useEffect } from 'react';
import './chatList.css'

const ChatList = () => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);


  useEffect(() => {
    const savedMessages = JSON.parse(localStorage.getItem('chatMessages')) || [];
    setMessages(savedMessages);
  }, []);

 
  const handleMessageChange = (event) => {
    setMessage(event.target.value);
  };

 
  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage = {
        text: message,
        timestamp: new Date().toLocaleString(), 
      };
   
      const updatedMessages = [...messages, newMessage];
      setMessages(updatedMessages);
      
     
      localStorage.setItem('chatMessages', JSON.stringify(updatedMessages));

     
      setMessage('');
    }
  };

  return (
    <div className="container mt-5">
      <div className="card">
        <div className="card-header">
          <h3>Group Chat</h3>
        </div>
        <div className="card-body" style={{ maxHeight: '400px', overflowY: 'scroll' }}>
          {/* Display each message with timestamp */}
          <div className="message-list">
          {messages.map((msg, index) => (
  <div  key={index}>
    <p>
      <span>[{msg.timestamp}]: </span>
      <span>{msg.text}</span>
    </p>
  </div>
))}
          </div>
        </div>
        <div className="card-footer d-flex">
          <input
            type="text"
            value={message}
            onChange={handleMessageChange}
            placeholder="Type a message"
            className="form-control me-2"
          />
          <button onClick={handleSendMessage} className="btn btn-primary spacer">
            Send
          </button>
          <button  className="btn btn-primary spacer">
            Refresh
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatList;
