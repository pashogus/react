import React from "react";
import { Link, Outlet } from "react-router-dom";


function Nav() {
    return (<>
       <nav class="nav">
                    <ul class="nav justify-content-center">
                        
                        <li className="nav-item">
                            <Link className="nav-link" to="/chatList">Chat List</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/userList">User List</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/documentList">Document List</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/logout">Logout</Link>
                        </li>
                  
                    </ul>

        </nav>
        <div className="container">
            <Outlet />
        </div>
    </>);
}

export default Nav;
