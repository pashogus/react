import React from "react"

class DocumentList extends React.Component{

    render()
    {
        return <p>""</p> 
    }
}

export default DocumentList;