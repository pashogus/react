import React from "react"
import style from "./HeaderComponent.module.css"

class HeaderComponent extends React.Component {
    render() { 
        return <>
        <header>Communication Application</header>
        </>;
    }
}
 
export default HeaderComponent;