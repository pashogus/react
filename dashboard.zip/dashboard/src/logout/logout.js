import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate hook

const LogOut = () => {
  const navigate = useNavigate(); // Hook for navigation

  useEffect(() => {
    // Clear email and password from localStorage
    localStorage.removeItem("email");
    localStorage.removeItem("password");

    navigate("/");
  }, [navigate]); // Dependency array ensures this runs once when component mounts

  return <p>Logging out...</p>;
};

export default LogOut;
