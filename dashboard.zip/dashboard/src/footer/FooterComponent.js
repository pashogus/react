import React from "react"
import style from "./FooterComponent.module.css"

class FooterComponent extends React.Component {
    render() { 
        return <>
        <footer>Communication Application</footer>
        </>;
    }
}
 
export default FooterComponent;