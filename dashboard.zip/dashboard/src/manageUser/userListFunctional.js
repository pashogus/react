import  "./userFunctional.css"
import { useState, useEffect } from "react";

function UserListFunctional() {

    const [users, setUsers] = useState([]);

    useEffect(() => {
        setUsers(JSON.parse(localStorage.getItem('users')))
    },[])

    return ( <section class="functional">
    <h2>Users Functional</h2>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>Name</th>
                        <th>User Email ID</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.map( (users,index) => 
                        <tr>
                            <td>index</td> 
                            <td>{users.name}</td>
                            <td>{users.email}</td>
                            <td> <a href=""  >Edit</a> | <a href="" onClick={(e) => this.deleteUserInfo(e)}>Delete</a> </td>
                        </tr>)
                    }
                </tbody>
            </table>

    </section> );
}

export default UserListFunctional;