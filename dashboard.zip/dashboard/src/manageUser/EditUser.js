import React from "react"

class EditUser extends React.Component{

    render()
    {
        return <section>

<form onSubmit={this.handleSubmission} className="form">
       
      <h1>Edit User Information</h1>
       <p>
      <label htmlFor="fullName">Full Name</label>
      <input type="text" id="fullName"  />
      </p>

      <p>
      <label htmlFor="email">Email</label>
      <input type="email" id="email"  />
      </p>

      <button>save</button>
      </form>
        </section>
    }
}

export default EditUser