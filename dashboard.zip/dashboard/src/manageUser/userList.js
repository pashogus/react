
import React from "react"
import ConfirmModal from './../util/confirmModal'

class UserList  extends React.Component {
    
    state= {
      users:JSON.parse(localStorage.getItem('users')),
      isModel:false
    }

  
   onConfirm()
   {
       console.log("on confirm");
   }

   onCancel()
   {
       console.log("on cancel");
   }

   deleteUserInfo  = (event) => {
      event.preventDefault(); 
       console.log("in delete user")
       this.setState({
        isModel: true, 
       })
       console.log(this.state)
   }

    render() { 
        return ( <section>
            <h2>Users</h2>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>Name</th>
                        <th>User Email ID</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {
                        this.state.users.map( (users,index) => 
                        <tr>
                            <td>index</td> 
                            <td>{users.name}</td>
                            <td>{users.email}</td>
                            <td> <a href=""  >Edit</a> | <a href="" onClick={(e) => this.deleteUserInfo(e)}>Delete</a> </td>
                        </tr>)
                    }
                </tbody>
            </table>

            { this.state.isModel && (
            <ConfirmModal  message="are you sure you wnat to delete the user"
            onConfirm={this.onConfirm}
            onCancel={this.onCancel}/>
            )}

        </section> );
    }
}
 
export default UserList;