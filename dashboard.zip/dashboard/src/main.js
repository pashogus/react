import React ,{ useState,useEffect }from "react"
import Welcome from './welcome/Welcome';
import Login from './login/login'
import Register from './register/Register';
import RegistrationSuccess from './register/RegistrationSuccess';
import HeaderComponent from './header/HeaderComponent';
import FooterComponent from './footer/FooterComponent';
import LoginSuccess from './login/loginSuccess';
import UserList from './manageUser/userList';
import EditUser from './manageUser/EditUser';
import ChatList from './chat/chatList';
import LogOut from './logout/logout';
import Nav from './Nav.js'
import DocumentList from './document/documentList';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';
import UserListFunctional from "./manageUser/userListFunctional";
import {BrowserRouter,Routes,Route} from 'react-router-dom'

 const  Main = () => {
 
        const users = [
            {  name: "test1", email: "test1@example.com" },
            {  name: "test2", email: "test2@example.com" },
            {  name: "test2", email: "test3@example.com" },
    
          ]
          localStorage.setItem('users',JSON.stringify(users));
         const [isLoggedIn, setIsLoggedIn] = useState(false);

         
          useEffect(() => {
            // Get the email and password from localStorage
            const email = localStorage.getItem('email');
            const password = localStorage.getItem('password');
        
            // Check if both email and password are present in localStorage
            if (email !== null && password !== null) {
              setIsLoggedIn(true); // User is logged in
            } else {
              setIsLoggedIn(false); // User is not logged in
            }
          }, []);

    
    // Exporting a component
     // lifecycle
        return <section className="rootSection"> 
        <HeaderComponent /> 
        <BrowserRouter>
        {isLoggedIn && <Nav />}
        <Routes>
            <Route path="/" element={isLoggedIn ? <ChatList /> : <Welcome />} />
            <Route path="/login" element={ <Login/>}></Route>
            <Route path="/loginSuccess" element={  <LoginSuccess/>}></Route>
            <Route path="/register" element={<Register />}></Route>
            <Route path="/registrationSuccess" element={<RegistrationSuccess />}></Route>
            <Route path="/userList" element={<UserList/>}></Route>
            <Route path="/chatList" element={ <ChatList/>}></Route>
            <Route path="/documentList" element={<DocumentList/>}></Route>
            <Route path="/userListFunctional" element={<UserListFunctional/>}></Route>
            <Route path="/logout" element={<LogOut/>}></Route>
         </Routes>
         </BrowserRouter>
        <FooterComponent/>
    </section>
    

    }

export default Main
